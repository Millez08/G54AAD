#include <stdio.h>
#include <string.h>
#include <unistd.h>


//Data file
char* fnData = "artists.txt";

//Bloom filter file
char* fnBloom = "bloom_filter.bin";

//Number of bits in the Bloom filter
int m = 17715833;

//Number of hash functions
int k = 7;



unsigned long hashFunc(unsigned char *str, unsigned long seed)
{
	unsigned long hash = seed;
	int c;

	while (c = *str++) {
		if (c >= 32) {
			hash = c + (hash << 6) + (hash << 16) - hash;
		}
	}
	
	return hash % m;
}



void setBit(unsigned long *bitArray, unsigned long index) {
	unsigned long indexArray = index / (sizeof(long)*8);
	unsigned long indexBit = index % (sizeof(long)*8);
	
	bitArray[indexArray] |= (unsigned long) 1 << indexBit;
}



int getBit(unsigned long *bitArray, unsigned long index) {
	unsigned long indexArray = index / (sizeof(long)*8);
	unsigned long indexBit = index % (sizeof(long)*8);
	
	return (bitArray[indexArray] << sizeof(long)*8-indexBit-1) >> sizeof(long)*8-1;
}



void printUsage() {
	printf("Usage: Main <options>\n");
	printf("where possible options include:\n");
	printf("  -bf               Create Bloom filter from the data set\n");
	printf("  -mem <string>     Check membership of a string in the Bloom filter\n");
	printf("  -add <string>     Add a string to the Bloom filter\n\n");
}



void createBloomFilter() {
	int i;
	
	printf("Creating Bloom filter...\n");
	
	int bitArraySize = ((sizeof(long)*8)-1+m)/(sizeof(long)*8);
	unsigned long bitArray[bitArraySize];
	for (i = 0; i < bitArraySize; i ++) {
		bitArray[i] = 0;
	}
	
	FILE* fpData = fopen(fnData, "r");
	
	char buf[256];
	while (fgets(buf, sizeof(buf), fpData)) {
		for (i = 0; i < k; i ++) {
			unsigned long hash = hashFunc(buf, i);
			setBit(bitArray, hash);
		}
	}
	
	fclose(fpData);
	
	FILE* fpBloom = fopen(fnBloom, "wb");
	fwrite(bitArray, sizeof(bitArray), 1, fpBloom);
	fclose(fpBloom);
	printf("Bloom filter saved as %s\n\n", fnBloom);
}



void checkMembership(char* string) {
	int i;
	
	if(access(fnBloom, F_OK) == -1) {
		printf("Bloom filter has not been created\n\n");
		return;
	}
	
	printf("Checking membership: \"%s\"\n", string);
	
	int bitArraySize = ((sizeof(long)*8)-1+m)/(sizeof(long)*8);
	unsigned long bitArray[bitArraySize];
	
	FILE* fpBloom = fopen(fnBloom, "rb");
	fread(bitArray, sizeof(bitArray), 1, fpBloom);
	fclose(fpBloom);
	
	int stringInDataSet = 1;
	for (i = 0; i < k; i ++) {
		unsigned long hash = hashFunc(string, i);
		if (getBit(bitArray, hash) == 0) {
			stringInDataSet = 0;
			break;
		}
	}
	if (stringInDataSet) {
		printf("String is possibly in the data set\n\n");
	}
	else {
		printf("String is definitely not in the data set\n\n");
	}
}



void addString(char* string) {
	int i;
	
	if(access(fnBloom, F_OK) == -1) {
		printf("Bloom filter has not been created\n\n");
		return;
	}
	
	printf("Adding to Bloom filter: \"%s\"\n", string);
	
	int bitArraySize = ((sizeof(long)*8)-1+m)/(sizeof(long)*8);
	unsigned long bitArray[bitArraySize];
	
	FILE* fpBloom = fopen(fnBloom, "rb");
	fread(bitArray, sizeof(bitArray), 1, fpBloom);
	fclose(fpBloom);
	
	for (i = 0; i < k; i ++) {
		unsigned long hash = hashFunc(string, i);
		setBit(bitArray, hash);
	}
	
	fpBloom = fopen(fnBloom, "wb");
	fwrite(bitArray, sizeof(bitArray), 1, fpBloom);
	fclose(fpBloom);
	
	printf("String added to Bloom filter\n\n");
}



int main(int argc, char *argv[]) {
	if(access(fnData, F_OK) == -1) {
		printf("File %s does not exist\n\n", fnData);
		return;
	}
	
	if (argc < 2 || argc > 3) {
		printUsage();
	}
	else {
		if (! strcmp(argv[1], "-bf")) {
			if (argc == 2) {
				createBloomFilter();
			}
			else {
				printUsage();
			}
		}
		else if (! strcmp(argv[1], "-mem")) {
			if (argc == 3) {
				checkMembership(argv[2]);
			}
			else {
				printUsage();
			}
		}
		else if (! strcmp(argv[1], "-add")) {
			if (argc == 3) {
				addString(argv[2]);
			}
			else {
				printUsage();
			}
		}
		else {
			printUsage();
		}
	}
}
