./Main -bf
./Main -mem "Arctic Monkeys"
./Main -mem "Sum 41"
./Main -mem "My New Artist"
./Main -add "My New Artist"
./Main -mem "My New Artist"
